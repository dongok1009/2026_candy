import React from 'react';
import { History, Play, Trash2, Download, ExternalLink, TrendingUp, Calendar, Activity } from 'lucide-react';
import './BacktestHistoryArchive.css';

const BacktestHistoryArchive = ({ records, onSelect, onDelete }) => {
    if (!records || records.length === 0) {
        return (
            <div className="history-empty">
                <History size={48} opacity={0.2} />
                <p>No saved backtest records found.</p>
            </div>
        );
    }

    // Sort by timestamp descending
    const sortedRecords = [...records].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    return (
        <section className="history-archive">
            <div className="archive-header">
                <h3><History size={18} /> Saved Backtest Archive</h3>
                <span className="count-badge">{records.length} Records</span>
            </div>

            <div className="archive-grid">
                {sortedRecords.map((record) => {
                    const roiNum = parseFloat(record.stats.roi.replace('%', ''));
                    const isPositive = roiNum > 0;
                    
                    return (
                        <div key={record.version} className="archive-card">
                            <div className="card-top">
                                <div className="version-info">
                                    <span className="version-tag">{record.version}</span>
                                    <span className="base-version">Base: {record.baseVersion}</span>
                                    <span className="symbol-tag" style={{ 
                                        marginLeft: '8px', 
                                        fontSize: '10px', 
                                        color: '#f3ba2f', 
                                        background: 'rgba(243, 186, 47, 0.1)', 
                                        padding: '1px 6px', 
                                        borderRadius: '4px',
                                        fontWeight: 'bold',
                                        border: '1px solid rgba(243, 186, 47, 0.2)'
                                    }}>
                                        {record.config?.symbol || 'BTCUSDT'}
                                    </span>
                                </div>
                                <div className="timestamp">
                                    <Calendar size={12} />
                                    {(() => {
                                        try {
                                            const d = new Date(record.timestamp);
                                            return isNaN(d.getTime()) ? record.timestamp : d.toLocaleString('ko-KR', {
                                                timeZone: 'Asia/Seoul',
                                                year: 'numeric', month: '2-digit', day: '2-digit',
                                                hour: '2-digit', minute: '2-digit',
                                                hour12: false
                                            }).replace(/\. /g, '-').replace('.', '');
                                        } catch(e) { return record.timestamp; }
                                    })()}
                                </div>
                            </div>

                            <div className="stats-row">
                                <div className="stat-mini">
                                    <span className="label">ROI</span>
                                    <span className={`value ${isPositive ? 'positive' : 'negative'}`}>
                                        {record.stats.roi}
                                    </span>
                                </div>
                                <div className="stat-mini">
                                    <span className="label">WIN RATE</span>
                                    <span className="value text-gold">{record.stats.winRate}</span>
                                </div>
                                <div className="stat-mini">
                                    <span className="label">TRADES</span>
                                    <span className="value">{record.stats.trades}</span>
                                </div>
                            </div>

                            <div className="period-box">
                                <span className="label">PERIOD</span>
                                <span className="period-text">{record.stats.period}</span>
                            </div>

                            <div className="card-actions">
                                <button className="action-btn load" onClick={() => onSelect(record.version)}>
                                    <Play size={14} /> Restore Config
                                </button>
                                {record.detailFile && (
                                    <a 
                                        className="action-btn download" 
                                        href={`http://localhost:3001/api/download?file=${encodeURIComponent(record.detailFile)}`}
                                        title="Download Detailed CSV"
                                    >
                                        <Download size={14} />
                                    </a>
                                )}
                                <button 
                                    className="action-btn delete" 
                                    onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        console.log("!!! DELETE CLICK DETECTED !!!", record.version);
                                        onDelete(record.version);
                                    }} 
                                    title="Delete Record"
                                    style={{ cursor: 'pointer', zIndex: 100 }}
                                >
                                    <Trash2 size={14} style={{ pointerEvents: 'none' }} />
                                </button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </section>
    );
};

export default BacktestHistoryArchive;
